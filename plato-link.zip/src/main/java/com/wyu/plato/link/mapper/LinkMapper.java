package com.wyu.plato.link.mapper;

import com.wyu.plato.link.model.LinkDO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author novo
 * @since 2023-03-11
 */
public interface LinkMapper extends BaseMapper<LinkDO> {

}
