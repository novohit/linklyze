package com.wyu.plato.link.service;

import com.wyu.plato.link.model.LinkMappingDO;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author novo
 * @since 2023-03-16
 */
public interface LinkMappingService extends IService<LinkMappingDO> {

}
